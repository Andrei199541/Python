<template>
  <footer class="p-3 fixed-bottom bg-light">
    <p class="text-center">&copy; Copyright 2019, All rights reserved</p>
  </footer>
</template>

<script>
export default {
  name: 'BlockHeader',
}
</script>